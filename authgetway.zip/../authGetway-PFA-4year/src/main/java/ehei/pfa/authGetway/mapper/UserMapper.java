package ehei.pfa.authGetway.mapper;

import ehei.pfa.authGetway.DTO.AdminCreateUserDTO;
import ehei.pfa.authGetway.DTO.auth.RegisterDTO;
import ehei.pfa.authGetway.DTO.res.MeDTO;
import ehei.pfa.authGetway.DTO.res.RegisterResDTO;
import ehei.pfa.authGetway.DTO.res.UserResDTO;
import ehei.pfa.authGetway.database.entity.User;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public User toEntity(RegisterDTO dto) {
        User user = new User();
        user.setEmail(dto.getEmail());
        return user;
    }

    public User toEntity(AdminCreateUserDTO dto) {
        User user = new User();
        user.setEmail(dto.getEmail());
        return user;
    }

    public RegisterResDTO toRegisterRes(User user, String accessToken) {
        return new RegisterResDTO(
                user.getId(),
                user.getEmail(),
                user.isVerifiedEmail(),
                user.getName(),
                user.getLastName(),
                user.getRole(),
                accessToken
        );
    }

    public UserResDTO toUserResDTO(User user) {
        return new UserResDTO(
                user.getId(),
                user.getEmail(),
                user.isVerifiedEmail(),
                user.getRole());
    }

    public MeDTO toMeDTO(User user) {
        return new MeDTO(
                user.getEmail(),
                user.isVerifiedEmail(),
                user.getRole()
        );
    }
}
