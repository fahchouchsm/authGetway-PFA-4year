package ehei.pfa.authGetway.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class AppProperties {
    private boolean useHttps = false;
    private String jwtSecret;
    private String jwtRefreshSecret;
}